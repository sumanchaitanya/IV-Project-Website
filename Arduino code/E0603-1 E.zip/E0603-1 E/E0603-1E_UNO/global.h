#ifndef GLOBAL_H
#define GLOBAL_H

//#include <SoftwareSerial.h>
//SoftwareSerial ss(A0, A1); //RX TX

#define Min 60
#define MAX_AMOUNT 3
#define RC_MAX_AMOUNT 9

#define D_BUZZER 3
#define D_RELAY  4

/**********global variables**********/
enum
{
  HOME = 1,
  CARD_READ = 2,
  CARD_LESS = 3,
  PAYMENT = 4,
  CHARGING = 5,
  MOBILE_RECHARGE = 6
} STATES;

volatile uint8_t present_state = HOME;
volatile uint8_t previous_state = HOME;

volatile uint8_t card_amount = 0;
int user_amount = 0;
volatile uint16_t time_period = 0;
/*******************************************/

char python_data='X';
int amount = 0;

#endif

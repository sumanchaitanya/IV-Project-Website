#ifndef IOTKEYPAD_H
#define IOTKEYPAD_H

#define R0 5
#define R1 6
#define R2 7
#define R3 8
#define C0 9
#define C1 10
#define C2 11
#define C3 12



volatile char key_value = 'x';

void keypad_init() {
  // put your setup code here, to run once:
  pinMode(R0, OUTPUT);
  pinMode(R1, OUTPUT);
  pinMode(R2, OUTPUT);
  pinMode(R3, OUTPUT);
  pinMode(C0, INPUT_PULLUP);
  pinMode(C1, INPUT_PULLUP);
  pinMode(C2, INPUT_PULLUP);
  pinMode(C3, INPUT_PULLUP);
}

char key(void) {

  digitalWrite(R0, LOW);
  digitalWrite(R1, HIGH);
  digitalWrite(R2, HIGH);
  digitalWrite(R3, HIGH);

  if (digitalRead(C0) == LOW) {
    key_value = '1';

  }
  if (digitalRead(C1) == LOW) {
    key_value = '2';

  }
  if (digitalRead(C2) == LOW) {
    key_value = '3';

  }
  if (digitalRead(C3) == LOW) {
    key_value = 'A';

  }
  digitalWrite(R0, HIGH);
  digitalWrite(R1, LOW);
  digitalWrite(R2, HIGH);
  digitalWrite(R3, HIGH);

  if (digitalRead(C0) == LOW) {
    key_value = '4';

  }
  if (digitalRead(C1) == LOW) {
    key_value = '5';

  }
  if (digitalRead(C2) == LOW) {
    key_value = '6';

  }
  if (digitalRead(C3) == LOW) {
    key_value = 'B';

  }
  digitalWrite(R0, HIGH);
  digitalWrite(R1, HIGH);
  digitalWrite(R2, LOW);
  digitalWrite(R3, HIGH);

  if (digitalRead(C0) == LOW) {
    key_value = '7';

  }
  if (digitalRead(C1) == LOW) {
    key_value = '8';

  }
  if (digitalRead(C2) == LOW) {
    key_value = '9';

  }
  if (digitalRead(C3) == LOW) {
    key_value = 'C';

  }
  digitalWrite(R0, HIGH);
  digitalWrite(R1, HIGH);
  digitalWrite(R2, HIGH);
  digitalWrite(R3, LOW);

  if (digitalRead(C0) == LOW) {
    key_value = '*';

  }
  if (digitalRead(C1) == LOW) {
    key_value = '0';

  }
  if (digitalRead(C2) == LOW) {
    key_value = '#';
  }
  if (digitalRead(C3) == LOW) {
    key_value = 'D';
  }
  return key_value;
}
#endif

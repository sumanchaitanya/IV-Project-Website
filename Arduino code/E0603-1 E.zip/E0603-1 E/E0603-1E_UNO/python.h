#ifndef PYTHON_H
#define PYTHON_H
#include "global.h"

void serialEvent()
{
  while (Serial.available())
  {
    python_data = (char)Serial.read();
    Serial.print(python_data);
  }
}



void python(void)
{
  switch (python_data)
  {
    case 'A' :
      amount = 50;
      python_data = 'X';
      break;
    case 'B' :
      amount = 100;
      python_data = 'X';
      break;
    case 'C' :
      amount = 200;
      python_data = 'X';
      break;
  }
  //return amount;
}
#endif

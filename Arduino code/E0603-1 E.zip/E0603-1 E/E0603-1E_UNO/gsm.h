#ifndef GSM_H
#define GSM_H

char num[5][11] = {"8328525358", "7538882431", "0000000000", "0000000000", "0000000000"};

void send_sms(String data)
{
  //Serial.println();
  Serial.println("AT");
  delay(1000);
  Serial.println("AT+CMGF=1");
  delay(1000);
  Serial.println("AT+CMGS=\"+91" + String(num[rfid() - 1]) + "\"\r");
  delay(1000);
  Serial.println(data);
  delay(200);
  Serial.write(char(26));
}
#endif

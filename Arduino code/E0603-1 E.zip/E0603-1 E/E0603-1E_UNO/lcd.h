#ifndef LCD_H
#define LCD_H
#include <Wire.h> 
#include <LiquidCrystal.h>              // Set the LCD address to 0x27 for a 16 chars and 2 line display
LiquidCrystal lcd(22, 24, 26, 28, 30, 32);
#endif

#ifndef UI_H
#define UI_H
#include "global.h"
#include "lcd.h"
#include "eeprom.h"
#include "ui.h"
#include "rfid.h"
#include "keypad.h"
#include "python.h"
#include "gsm.h"
#include "iot.h"
#include "ss.h"



void recharge(void);

void ui()
{
  switch (present_state)
  {
    case HOME:
      {
        digitalWrite(D_BUZZER, LOW);
        card_amount = 0;
        rfidno = 0;
        key_value = 'x';
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("1.CARD");
        lcd.setCursor(0, 1);
        lcd.print("2.CARDLESS");
        if (key() == '1')
        {
          present_state = CARD_READ;
        }
        if (key() == '2')
        {
          present_state = CARD_LESS;
        }
      }
      break;

    case CARD_READ:
      {
        lcd.clear();
        digitalWrite(D_BUZZER, LOW);
        if (rfid() != 0)
        {
          card_amount = EEPROM.read(rfid());
          lcd.setCursor(0, 0);
          lcd.print("BAL:");
          lcd.setCursor(4, 0);
          lcd.print(card_amount * 100);
          lcd.setCursor(10, 0);
          lcd.print("EXIT:0");
          lcd.setCursor(0, 1);
          lcd.print("CHRGE:*");
          lcd.setCursor(8, 1);
          lcd.print("RECHRG:#");
        }
        else
        {
          lcd.setCursor(0, 0);
          lcd.print("READING ID.... ");
          rfidno = 0;
        }
        switch (key())
        {
          case '#':
            key_value = 'x';
            present_state = MOBILE_RECHARGE;
            previous_state = CARD_READ;
            break;

          case '0':
            key_value = 'x';
            rfidno = 0;
            card_amount = 0;
            present_state = HOME;
            previous_state = HOME;
            break;

          case '*':
            key_value = 'x';
            present_state = CHARGING;
            previous_state = PAYMENT;
            break;
        }
        break;
      }
      break;
    case CARD_LESS:
      {
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("GIVE THE AMOUNT");
        lcd.setCursor(7, 1);
        lcd.print("*.CONFIRM");
        python();
        user_amount += amount;
        amount = 0;
        Serial.println(user_amount);
        lcd.setCursor(0, 1);
        lcd.print(user_amount);
        if (key() == '*')
        {
          time_period = Min * (user_amount / 100);
          present_state = CHARGING;
          previous_state = CARD_LESS;
        }
      }
      break;
    case MOBILE_RECHARGE:
      {
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("PLS PAY AMOUNT");
        lcd.setCursor(10, 1);
        lcd.print("EXIT:0");
        lcd.setCursor(0, 1);
        lcd.print("RESET:*");
        switch (key())
        {
          case 'A':
            key_value = 'x';
            recharge();
            break;
          case '*':
            key_value = 'x';
            eeprom_clear();
            card_amount = EEPROM.read(rfid());
            present_state = HOME;
            previous_state = HOME;
            break;
          case '0':
            key_value = 'x';
            present_state = CARD_READ;
            previous_state = HOME;
            break;
        }
        break;
      }
    case CHARGING:
      {
        switch (previous_state)
        {
          case PAYMENT:
            {
              switch (key())
              {
                case '1':
                  key_value = 'x';
                  user_amount = 1;
                  break;
                case '2':
                  key_value = 'x';
                  user_amount = 2;
                  break;
                case '3':
                  key_value = 'x';
                  user_amount = 3;
                  break;
              }
              time_period = Min * user_amount;
              lcd.clear();
              lcd.setCursor(0, 0);
              lcd.print("CHS AMT:");
              lcd.setCursor(10, 0);
              lcd.print("1.100");
              lcd.setCursor(0, 1);
              lcd.print("2.200");
              lcd.setCursor(6, 1);
              lcd.print("3.300");
              if (user_amount > card_amount)
              {
                user_amount = 0;
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print("PLS RECHARGE OR");
                lcd.setCursor(0, 1);
                lcd.print("ENTER VALID AMT");
                present_state = CARD_READ;
              }
              else if (user_amount != 0 && user_amount <= card_amount)
              {
                user_amount = 0;
                present_state = CHARGING;
                previous_state = CARD_READ;
              }
              break;
            }

          case CARD_READ:
            {
              if (time_period != 0 )
              {
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print("CHARGING..");
                lcd.setCursor(15, 0);
                lcd.print("S");
                lcd.setCursor(0, 1);
                lcd.print("AMT:");
                lcd.setCursor(10, 1);
                lcd.print("8-STOP");
                digitalWrite(D_RELAY, HIGH);
                lcd.setCursor(5, 0);
                lcd.print("ON");
              }
              lcd.setCursor(11, 0);
              lcd.print(time_period);
              lcd.setCursor(4, 1);
              lcd.print(card_amount * 100);

              if ((time_period == 0) || (key() == '8'))
              {
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print("THANK YOU...");
                digitalWrite(D_RELAY, LOW);
                EEPROM.write(rfid(), card_amount);
                time_period = 0;

                for (int i = 0; i < 5; i++)
                {
                  digitalWrite(D_BUZZER, HIGH);
                  delay(150);
                  digitalWrite(D_BUZZER, LOW);
                  delay(150);
                }
                int amount = EEPROM.read(rfid()) * 100;
                send_sms("charging finished,have a safe journey remaining amount : " + String(amount));
                iot_send("*charging finished,have a safe journey#");
                iot_send("%" + String(amount) + "#");
                present_state = HOME;
              }
              if ((time_period % 60) == 0)
              {
                card_amount--;
              }
              time_period--;
            }
            break;

          case CARD_LESS:
            {
              if (time_period != 0 )
              {
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print("CHARGING");
                lcd.setCursor(15, 0);
                lcd.print("S");
                digitalWrite(D_RELAY, HIGH);
              }

              lcd.setCursor(11, 0);
              lcd.print(time_period);

              if ((time_period == 0) || (key() == '8'))
              {
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print("THANK YOU...");
                digitalWrite(D_RELAY, LOW);
                time_period = 0;
                user_amount = 0;
                key_value = 'x';
                for (int i = 0; i < 5; i++)
                {
                  digitalWrite(D_BUZZER, HIGH);
                  delay(150);
                  digitalWrite(D_BUZZER, LOW);
                  delay(150);
                }
                present_state = HOME;
              }
              time_period--;
            }
            break;
        }
      }
      break;
  }
}


void recharge(void)
{
  int temp = EEPROM.read(rfid());
  temp = temp + MAX_AMOUNT;
  lcd.clear();
  if (temp <= RC_MAX_AMOUNT)
  {
    EEPROM.write(rfid(), temp);
    lcd.setCursor(0, 0);
    lcd.print("RC SUCCESS..");
  }
  else
  {
    lcd.setCursor(0, 0);
    lcd.print("RC LIMIT REACHED..");
  }
  present_state = CARD_READ;
}

#endif
